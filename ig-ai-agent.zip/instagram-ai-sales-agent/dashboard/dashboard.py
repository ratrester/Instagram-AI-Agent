from flask import Flask, render_template
import psycopg2, os

app = Flask(__name__)

DB_URL = os.getenv("DB_URL")

@app.route("/")
def dashboard():
    conn = psycopg2.connect(DB_URL)
    cur = conn.cursor()
    cur.execute("SELECT * FROM leads ORDER BY date_added DESC;")
    leads = cur.fetchall()
    conn.close()
    return render_template("dashboard.html", leads=leads)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
