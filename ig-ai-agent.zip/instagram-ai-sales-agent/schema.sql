CREATE TABLE posts (
    post_id SERIAL PRIMARY KEY,
    post_url TEXT NOT NULL,
    date_posted TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE leads (
    lead_id SERIAL PRIMARY KEY,
    username TEXT NOT NULL,
    full_name TEXT,
    verified BOOLEAN,
    location TEXT,
    comment TEXT,
    follower_count INT,
    following_count INT,
    is_follower BOOLEAN DEFAULT FALSE,
    quality_score INT DEFAULT 0,
    date_added TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE outreach (
    outreach_id SERIAL PRIMARY KEY,
    lead_id INT REFERENCES leads(lead_id),
    status TEXT DEFAULT 'Pending',
    date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO posts (post_url) VALUES 
('https://instagram.com/p/testpost1/'),
('https://instagram.com/p/testpost2/');
