# PhantomBuster Setup

**Agents Needed:**
1. Instagram Photo Likers API
2. Instagram Post Commenters API

**Steps:**
- Log in to PhantomBuster
- Create new agent → choose "Instagram Photo Likers" or "Instagram Post Commenters"
- Input your Instagram session cookie (from your browser's developer tools)
- Paste list of post URLs from DB
- Set CSV export
- Schedule weekly run
