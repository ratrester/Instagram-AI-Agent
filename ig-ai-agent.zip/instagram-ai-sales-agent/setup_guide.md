# Setup Guide - Instagram AI Sales Agent

1. Create Instagram Business Account + Facebook Page.
2. Create Facebook Developer App → Add Instagram Graph API.
3. Generate long-lived access token.
4. Set up Neon or other PostgreSQL, import `schema.sql`.
5. Import `workflow.json` into Make.com or n8n.
6. Configure PhantomBuster agents using `phantombuster_config.md`.
7. Deploy `/dashboard` to Replit or Render.
8. Hire operator to do manual IG DMs.
